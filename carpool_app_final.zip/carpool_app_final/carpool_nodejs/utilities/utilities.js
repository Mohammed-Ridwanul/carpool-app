var express = require('express');

var Utilties = {
	someUtility : function() {
		console.log("Do something...");
	}
}

module.exports = Utilties;