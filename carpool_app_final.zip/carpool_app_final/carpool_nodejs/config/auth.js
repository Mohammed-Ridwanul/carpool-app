var express = require('express');
var router = express.Router();

// This file contains methods for user authentication

var Auth = {
	isLoggedOut: function(req,res,next){
		if(!req.user){
			next();
		} else{
			res.redirect('/');	
		}
	},
	
	isLoggedIn: function(req,res,next){
		if(req.user){
			next();
		} else{
			res.redirect('/login');	
		}
	},	
	
	isAdmin: function(req,res,next){
		if(!req.user && req.user.accounttype === "Admin"){
			next();
		} else{
			res.redirect('/login');	
		}
	}
}

module.exports = Auth;