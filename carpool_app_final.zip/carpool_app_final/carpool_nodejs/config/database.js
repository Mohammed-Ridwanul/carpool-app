// config/database.js
module.exports = {

    'url' : 'mongodb://futureblue:fTrbLu3CA@ds059804.mongolab.com:59804/carpool-app' // looks like mongodb://<user>:<pass>@mongo.onmodulus.net:27017/Mikha4ot

};