# NodeJS-Express-Template
This is a template for starting NodeJS Express 4 applications
