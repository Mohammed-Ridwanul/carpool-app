var express = require('express');
var passport = require('passport');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('register', { 
      title: 'Register for IBM Carpool',
      message: req.flash('message'),
      user: req.user 
    });
});

router.post('/', passport.authenticate('local-signup', {
        successRedirect : '/', // redirect to the homepage
        failureRedirect : '/register', // redirect back to the signup page if there is an error
        failureFlash : true // allow flash messages
    }));

module.exports = router;
