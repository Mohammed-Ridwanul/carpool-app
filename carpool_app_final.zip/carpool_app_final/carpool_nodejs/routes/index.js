var express = require('express');
var User = require('../models/user');
var Post = require('../models/post');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  Post.find({}).populate('user').exec(function(err, posts) {
    if (err) {
      throw err;
    } else {
      res.render('index', { 
        title: 'Open RideShare',
        posts: posts
      });
    }
  });
  
});

module.exports = router;
