var express = require('express');
var router = express.Router();
var Auth = require('../config/Auth.js')
var Post = require('../models/post')

/* GET home page. */
router.get('/', Auth.isLoggedIn, function(req, res, next) {
  res.render('createpost', { 
    title: 'Post a new carpool',
    user: req.user
  });
});

router.post('/', function(req,res,next){
  var newPost = new Post();
  newPost.startLocation = req.body.startLocation;
  newPost.finishLocation = req.body.finishLocation;  
  newPost.datePosted = req.body.datePosted;
  newPost.timeLeaving = req.body.timeLeaving;
  newPost.numSeats = req.body.numSeats;
  newPost.seatPrice = req.body.seatPrice;
  newPost.user = req.user;
  
  console.log(newPost);
  
  // save the post
  newPost.save(function(err){
    if(err){
      throw err;
    } else{
      res.render('createpost', { 
        title: 'Post a new carpool',
        user: req.user
      });
    }
  });
   
          
});

module.exports = router;
