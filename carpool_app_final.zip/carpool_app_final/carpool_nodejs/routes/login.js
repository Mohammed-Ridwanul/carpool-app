var express = require('express');
var passport = require('passport');
var Auth = require('../config/Auth.js');
var router = express.Router();

/* GET home page. */
router.get('/', Auth.isLoggedOut, function(req, res, next) {
  res.render('login', { 
      title: 'Login page',
      message: req.flash('message'),
      user: req.user 
    });
});

router.post('/', passport.authenticate('local-login', {
        successRedirect : '/', // redirect to the homepage
        failureRedirect : '/login', // redirect back to the signup page if there is an error
        failureFlash : true // allow flash messages
    }));

module.exports = router;
